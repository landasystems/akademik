<?php

return array(
    'version' => '1.0',
    'extract' => array(
        'to' => 'protected/extensions/'
    ),
);

