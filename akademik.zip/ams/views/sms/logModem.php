    <?php

    $this->beginWidget('application.extensions.prettify.JPrettify');
    echo $log;
    $this->endWidget();
    ?>