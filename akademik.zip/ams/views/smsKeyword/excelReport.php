<?php if ($model !== null):?>
<table border="1">

	<tr>
		<th width="80px">
		      id		</th>
 		<th width="80px">
		      name		</th>
 		<th width="80px">
		      description		</th>
 		<th width="80px">
		      type		</th>
 		<th width="80px">
		      options		</th>
 		<th width="80px">
		      autoreplys		</th>
 	</tr>
	<?php foreach($model as $row): ?>
	<tr>
        		<td>
			<?php echo $row->id; ?>
		</td>
       		<td>
			<?php echo $row->name; ?>
		</td>
       		<td>
			<?php echo $row->description; ?>
		</td>
       		<td>
			<?php echo $row->type; ?>
		</td>
       		<td>
			<?php echo $row->options; ?>
		</td>
       		<td>
			<?php echo $row->autoreplys; ?>
		</td>
       	</tr>
     <?php endforeach; ?>
</table>
<?php endif; ?>
