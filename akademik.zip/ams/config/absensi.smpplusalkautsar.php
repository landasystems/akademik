<?php
//=========change this scope=========================================================
$root = '/var/www/landa/';
$themesUrl = 'http://localhost/landa/common/themes/';
$db = 'landa_ams_smpplusalkautsar';
$dbUser = 'root';
$dbPwd = 'landak';
$client = 'absensi.smpplusalkautsar';
$clientName = 'SMP Plus Alkautsar MALANG - Sekolah bernuansa ISLAMI, berbasis IT, dan berwawasan lingkungan';
$menu = array();
$rootUrl = 'http://localhost/landa/ams/www/'.$client.'/';
//===================================================================================
?>

