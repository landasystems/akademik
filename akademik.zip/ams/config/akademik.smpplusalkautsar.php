<?php
//=========change this scope=========================================================
$root = '/var/www/akademik/';
$db = 'landa_ams_smpplusalkautsar';
$dbUser = 'root';
$dbPwd = 'landak';
$client = 'akademik.smpplusalkautsar';
$clientName = 'SMP Plus Alkautsar Malang';
//===================================================================================
?>
